﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using Microsoft.Data.SqlClient;

namespace LENSAmanager
{
    // Rezultatul demo-ului de batch insert, contine textul log SI datele pentru grafic
    public class BatchInsertResult
    {
        public string Log { get; set; } = "";
        public double Avg1 { get; set; }   // auto-commit
        public double Avg2 { get; set; }   // commit la 100
        public double Avg3 { get; set; }   // o singura tranzactie
        public List<long> Times1 { get; set; } = new();
        public List<long> Times2 { get; set; } = new();
        public List<long> Times3 { get; set; } = new();
    }

    internal static class TransactionDemos
    {
        // ─────────────────────────────────────────────────────────
        //  HELPERS
        // ─────────────────────────────────────────────────────────

        private static async Task<decimal> ReadSalariuAsync(int id)
        {
            using var conn = data.DatabaseManager.GetConnection();
            await conn.OpenAsync();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT salariu FROM Angajati WHERE id_angajat = @id";
            cmd.Parameters.AddWithValue("@id", id);
            var result = await cmd.ExecuteScalarAsync();
            return result == DBNull.Value || result == null ? 0m : Convert.ToDecimal(result);
        }

        private static async Task ResetSalariuAsync(int id, decimal valoare)
        {
            using var conn = data.DatabaseManager.GetConnection();
            await conn.OpenAsync();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "UPDATE Angajati SET salariu = @s WHERE id_angajat = @id";
            cmd.Parameters.AddWithValue("@s", valoare);
            cmd.Parameters.AddWithValue("@id", id);
            await cmd.ExecuteNonQueryAsync();
        }

        private static async Task<int> CountByFunctieAsync(string functie)
        {
            using var conn = data.DatabaseManager.GetConnection();
            await conn.OpenAsync();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT COUNT(*) FROM Angajati WHERE functie = @f";
            cmd.Parameters.AddWithValue("@f", functie);
            return Convert.ToInt32(await cmd.ExecuteScalarAsync());
        }

        // ─────────────────────────────────────────────────────────
        //  A. DIRTY READ
        // ─────────────────────────────────────────────────────────

        public static async Task<string> RunDirtyReadDemoAsync()
        {
            var log = new StringBuilder();
            const int id = 1;

            await ResetSalariuAsync(id, 5000m);
            log.AppendLine("=== DEMONSTRATIE DIRTY READ ===");
            log.AppendLine($"[INITIAL] Salariu angajat id=1 (committed) = {await ReadSalariuAsync(id)}");
            log.AppendLine();
            log.AppendLine("Scenariu: Tranzactia A modifica salariul la 10000 dar NU face commit.");
            log.AppendLine("         Tranzactia B citeste cu READ UNCOMMITTED => vede valoarea necomisa.");
            log.AppendLine();

            using var connA = data.DatabaseManager.GetConnection();
            await connA.OpenAsync();
            using var txA = connA.BeginTransaction(IsolationLevel.ReadCommitted);

            using var cmdA = connA.CreateCommand();
            cmdA.Transaction = txA;
            cmdA.CommandText = "UPDATE Angajati SET salariu = @s WHERE id_angajat = @id";
            cmdA.Parameters.AddWithValue("@s", 10000m);
            cmdA.Parameters.AddWithValue("@id", id);
            await cmdA.ExecuteNonQueryAsync();
            log.AppendLine("Tranzactia A: salariu actualizat la 10000 (NECOMIS, in asteptare...)");

            using (var connB = data.DatabaseManager.GetConnection())
            {
                await connB.OpenAsync();
                using var txB = connB.BeginTransaction(IsolationLevel.ReadUncommitted);
                using var cmdB = connB.CreateCommand();
                cmdB.Transaction = txB;
                cmdB.CommandText = "SELECT salariu FROM Angajati WHERE id_angajat = @id";
                cmdB.Parameters.AddWithValue("@id", id);
                var result = await cmdB.ExecuteScalarAsync();
                var bRead = result == DBNull.Value || result == null ? 0m : Convert.ToDecimal(result);
                log.AppendLine($"Tranzactia B (READ UNCOMMITTED): a citit salariul = {bRead}  <-- DIRTY READ!");
                await txB.CommitAsync();
                log.AppendLine("Tranzactia B: COMMIT efectuat");
            }

            await txA.RollbackAsync();
            log.AppendLine("Tranzactia A: ROLLBACK efectuat! Modificarea a fost anulata.");
            log.AppendLine();
            log.AppendLine($"[FINAL] Salariu committed dupa rollback = {await ReadSalariuAsync(id)}");
            log.AppendLine();
            log.AppendLine("CONCLUZIE: Tranzactia B a citit valoarea 10000 care nu a existat niciodata committed.");
            log.AppendLine("PREVENTIE: READ COMMITTED (sau mai strict) previne dirty reads.");

            return log.ToString();
        }

        // ─────────────────────────────────────────────────────────
        //  B. NON-REPEATABLE READ
        // ─────────────────────────────────────────────────────────

        public static async Task<string> RunNonRepeatableReadDemoAsync()
        {
            var log = new StringBuilder();
            const int id = 1;

            await ResetSalariuAsync(id, 5000m);
            log.AppendLine("=== DEMONSTRATIE NON-REPEATABLE READ ===");
            log.AppendLine($"[INITIAL] Salariu angajat id=1 = {await ReadSalariuAsync(id)}");
            log.AppendLine();
            log.AppendLine("Scenariu: Tranzactia A citeste salariul de doua ori (READ COMMITTED).");
            log.AppendLine("         Tranzactia B modifica si face commit intre cele doua citiri.");
            log.AppendLine();

            using var connA = data.DatabaseManager.GetConnection();
            await connA.OpenAsync();
            using var txA = connA.BeginTransaction(IsolationLevel.ReadCommitted);

            using var cmdA = connA.CreateCommand();
            cmdA.Transaction = txA;
            cmdA.CommandText = "SELECT salariu FROM Angajati WHERE id_angajat = @id";
            cmdA.Parameters.AddWithValue("@id", id);
            var first = await cmdA.ExecuteScalarAsync();
            var firstVal = first == DBNull.Value || first == null ? 0m : Convert.ToDecimal(first);
            log.AppendLine($"Tranzactia A: Prima citire salariu = {firstVal}");

            using (var connB = data.DatabaseManager.GetConnection())
            {
                await connB.OpenAsync();
                using var txB = connB.BeginTransaction(IsolationLevel.ReadCommitted);
                using var cmdB = connB.CreateCommand();
                cmdB.Transaction = txB;
                cmdB.CommandText = "UPDATE Angajati SET salariu = @s WHERE id_angajat = @id";
                cmdB.Parameters.AddWithValue("@s", 12000m);
                cmdB.Parameters.AddWithValue("@id", id);
                await cmdB.ExecuteNonQueryAsync();
                await txB.CommitAsync();
                log.AppendLine("Tranzactia B: salariu actualizat la 12000 si COMMITTED");
            }

            var second = await cmdA.ExecuteScalarAsync();
            var secondVal = second == DBNull.Value || second == null ? 0m : Convert.ToDecimal(second);
            log.AppendLine($"Tranzactia A: A doua citire salariu = {secondVal}  <-- VALOARE DIFERITA!");

            await txA.CommitAsync();
            log.AppendLine("Tranzactia A: COMMIT efectuat");
            log.AppendLine();
            log.AppendLine($"Prima citire: {firstVal}  |  A doua citire: {secondVal}");
            if (firstVal != secondVal)
                log.AppendLine("REZULTAT: Non-repeatable read demonstrat cu succes!");
            log.AppendLine();
            log.AppendLine("CONCLUZIE: Aceeasi interogare in aceeasi tranzactie a returnat valori diferite.");
            log.AppendLine("PREVENTIE: REPEATABLE READ sau SERIALIZABLE previn non-repeatable reads.");

            return log.ToString();
        }

        // ─────────────────────────────────────────────────────────
        //  C. PHANTOM READ
        // ─────────────────────────────────────────────────────────

        public static async Task<string> RunPhantomReadDemoAsync()
        {
            var log = new StringBuilder();
            const string functieTest = "Vanzator";

            log.AppendLine("=== DEMONSTRATIE PHANTOM READ ===");
            log.AppendLine($"[INITIAL] Numar angajati cu functia '{functieTest}' = {await CountByFunctieAsync(functieTest)}");
            log.AppendLine();
            log.AppendLine($"Scenariu: Tranzactia A numara angajatii cu functia '{functieTest}' de doua ori (REPEATABLE READ).");
            log.AppendLine("         Tranzactia B insereaza un angajat nou cu aceeasi functie intre cele doua numaratori.");
            log.AppendLine();

            using var connA = data.DatabaseManager.GetConnection();
            await connA.OpenAsync();
            using var txA = connA.BeginTransaction(IsolationLevel.RepeatableRead);

            using var cmdA = connA.CreateCommand();
            cmdA.Transaction = txA;
            cmdA.CommandText = "SELECT COUNT(*) FROM Angajati WHERE functie = @f";
            cmdA.Parameters.AddWithValue("@f", functieTest);
            var first = Convert.ToInt32(await cmdA.ExecuteScalarAsync());
            log.AppendLine($"Tranzactia A: Prima numaratoare = {first}");

            string phantomPrenume = "PhantomTest";
            using (var connB = data.DatabaseManager.GetConnection())
            {
                await connB.OpenAsync();
                using var txB = connB.BeginTransaction(IsolationLevel.ReadCommitted);
                using var cmdB = connB.CreateCommand();
                cmdB.Transaction = txB;
                cmdB.CommandText = @"INSERT INTO Angajati (nume, prenume, functie, salariu)
                                     VALUES ('Phantom', @p, @f, 3000)";
                cmdB.Parameters.AddWithValue("@p", phantomPrenume);
                cmdB.Parameters.AddWithValue("@f", functieTest);
                await cmdB.ExecuteNonQueryAsync();
                await txB.CommitAsync();
                log.AppendLine("Tranzactia B: Angajat nou (Phantom) inserat si COMMITTED");
            }

            var second = Convert.ToInt32(await cmdA.ExecuteScalarAsync());
            log.AppendLine($"Tranzactia A: A doua numaratoare = {second}");

            await txA.CommitAsync();
            log.AppendLine("Tranzactia A: COMMIT efectuat");

            using var connClean = data.DatabaseManager.GetConnection();
            await connClean.OpenAsync();
            using var cmdClean = connClean.CreateCommand();
            cmdClean.CommandText = "DELETE FROM Angajati WHERE prenume = @p AND nume = 'Phantom'";
            cmdClean.Parameters.AddWithValue("@p", phantomPrenume);
            await cmdClean.ExecuteNonQueryAsync();

            log.AppendLine();
            log.AppendLine($"Prima numaratoare: {first}  |  A doua numaratoare: {second}");
            if (first != second)
                log.AppendLine("REZULTAT: Phantom read demonstrat! REPEATABLE READ nu previne insertii noi.");
            else
                log.AppendLine("REZULTAT: Nu s-a observat phantom (SQL Server poate folosi locking agresiv intern).");
            log.AppendLine();
            log.AppendLine("CONCLUZIE: Un rand 'fantoma' a aparut intre doua executii ale aceleiasi interogari.");
            log.AppendLine("PREVENTIE: SERIALIZABLE previne phantom reads prin range locks.");
            log.AppendLine("[CURATARE] Angajatul phantom a fost sters.");

            return log.ToString();
        }

        // ─────────────────────────────────────────────────────────
        //  D. LOST UPDATE
        // ─────────────────────────────────────────────────────────

        public static async Task<string> RunLostUpdateDemoAsync()
        {
            var log = new StringBuilder();
            const int id = 1;

            await ResetSalariuAsync(id, 5000m);
            log.AppendLine("=== DEMONSTRATIE LOST UPDATE ===");
            log.AppendLine($"[INITIAL] Salariu angajat id=1 = {await ReadSalariuAsync(id)}");
            log.AppendLine();
            log.AppendLine("Scenariu: Ambele tranzactii citesc 5000, calculeaza salariu nou si scriu.");
            log.AppendLine("         A adauga 1000 => 6000, B adauga 500 => 5500.");
            log.AppendLine("         A scrie ultima => 6000. Actualizarea lui B (5500) se pierde.");
            log.AppendLine();

            var taskA = Task.Run(async () =>
            {
                using var connA = data.DatabaseManager.GetConnection();
                await connA.OpenAsync();
                using var txA = connA.BeginTransaction(IsolationLevel.ReadCommitted);
                using var cmdRead = connA.CreateCommand();
                cmdRead.Transaction = txA;
                cmdRead.CommandText = "SELECT salariu FROM Angajati WHERE id_angajat = @id";
                cmdRead.Parameters.AddWithValue("@id", id);
                var read = Convert.ToDecimal(await cmdRead.ExecuteScalarAsync());
                log.AppendLine($"Tranzactia A: a citit salariul = {read}");
                var newSal = read + 1000m;

                await Task.Delay(600);

                using var cmdUpd = connA.CreateCommand();
                cmdUpd.Transaction = txA;
                cmdUpd.CommandText = "UPDATE Angajati SET salariu = @s WHERE id_angajat = @id";
                cmdUpd.Parameters.AddWithValue("@s", newSal);
                cmdUpd.Parameters.AddWithValue("@id", id);
                await cmdUpd.ExecuteNonQueryAsync();
                await txA.CommitAsync();
                log.AppendLine($"Tranzactia A: a scris salariul = {newSal} si COMMITTED (suprascrie B!)");
            });

            var taskB = Task.Run(async () =>
            {
                await Task.Delay(100);
                using var connB = data.DatabaseManager.GetConnection();
                await connB.OpenAsync();
                using var txB = connB.BeginTransaction(IsolationLevel.ReadCommitted);
                using var cmdRead = connB.CreateCommand();
                cmdRead.Transaction = txB;
                cmdRead.CommandText = "SELECT salariu FROM Angajati WHERE id_angajat = @id";
                cmdRead.Parameters.AddWithValue("@id", id);
                var read = Convert.ToDecimal(await cmdRead.ExecuteScalarAsync());
                log.AppendLine($"Tranzactia B: a citit salariul = {read}");
                var newSal = read + 500m;

                using var cmdUpd = connB.CreateCommand();
                cmdUpd.Transaction = txB;
                cmdUpd.CommandText = "UPDATE Angajati SET salariu = @s WHERE id_angajat = @id";
                cmdUpd.Parameters.AddWithValue("@s", newSal);
                cmdUpd.Parameters.AddWithValue("@id", id);
                await cmdUpd.ExecuteNonQueryAsync();
                await txB.CommitAsync();
                log.AppendLine($"Tranzactia B: a scris salariul = {newSal} si COMMITTED");
            });

            await Task.WhenAll(taskA, taskB);

            var final = await ReadSalariuAsync(id);
            log.AppendLine();
            log.AppendLine($"[FINAL] Salariu dupa ambele commit-uri = {final}");
            log.AppendLine();
            log.AppendLine("CONCLUZIE: Actualizarea lui B (+500) s-a pierdut complet.");
            log.AppendLine("PREVENTIE: Folositi SELECT ... WITH (UPDLOCK) sau optimistic concurrency.");

            return log.ToString();
        }

        // ─────────────────────────────────────────────────────────
        //  E. DEADLOCK
        // ─────────────────────────────────────────────────────────

        public static async Task<string> RunDeadlockDemoAsync()
        {
            var log = new StringBuilder();
            const int id1 = 1;
            const int id2 = 2;

            await ResetSalariuAsync(id1, 5000m);
            await ResetSalariuAsync(id2, 4500m);

            log.AppendLine("=== DEMONSTRATIE DEADLOCK ===");
            log.AppendLine($"[INITIAL] Salariu id=1: {await ReadSalariuAsync(id1)}, Salariu id=2: {await ReadSalariuAsync(id2)}");
            log.AppendLine();
            log.AppendLine("Scenariu: A blocheaza randul 1, B blocheaza randul 2.");
            log.AppendLine("         A vrea randul 2 (blocat de B), B vrea randul 1 (blocat de A).");
            log.AppendLine("         => SQL Server detecteaza deadlock si alege o victima.");
            log.AppendLine();

            var taskA = Task.Run(async () =>
            {
                try
                {
                    using var connA = data.DatabaseManager.GetConnection();
                    await connA.OpenAsync();
                    using var txA = connA.BeginTransaction(IsolationLevel.ReadCommitted);
                    using var cmd1 = connA.CreateCommand();
                    cmd1.Transaction = txA;
                    cmd1.CommandText = "UPDATE Angajati SET salariu = salariu + 10 WHERE id_angajat = @id";
                    cmd1.Parameters.AddWithValue("@id", id1);
                    await cmd1.ExecuteNonQueryAsync();
                    log.AppendLine("Tranzactia A: a blocat randul id=1");
                    await Task.Delay(2000);
                    using var cmd2 = connA.CreateCommand();
                    cmd2.Transaction = txA;
                    cmd2.CommandText = "UPDATE Angajati SET salariu = salariu + 10 WHERE id_angajat = @id";
                    cmd2.Parameters.AddWithValue("@id", id2);
                    await cmd2.ExecuteNonQueryAsync();
                    await txA.CommitAsync();
                    log.AppendLine("Tranzactia A: a blocat randul id=2 si COMMITTED");
                }
                catch (SqlException ex) when (ex.Number == 1205)
                {
                    log.AppendLine("Tranzactia A: VICTIMA DEADLOCK! SQL Server a anulat aceasta tranzactie.");
                }
                catch (Exception ex)
                {
                    log.AppendLine($"Tranzactia A: Eroare - {ex.Message}");
                }
            });

            var taskB = Task.Run(async () =>
            {
                try
                {
                    await Task.Delay(200);
                    using var connB = data.DatabaseManager.GetConnection();
                    await connB.OpenAsync();
                    using var txB = connB.BeginTransaction(IsolationLevel.ReadCommitted);
                    using var cmd1 = connB.CreateCommand();
                    cmd1.Transaction = txB;
                    cmd1.CommandText = "UPDATE Angajati SET salariu = salariu + 5 WHERE id_angajat = @id";
                    cmd1.Parameters.AddWithValue("@id", id2);
                    await cmd1.ExecuteNonQueryAsync();
                    log.AppendLine("Tranzactia B: a blocat randul id=2");
                    await Task.Delay(2000);
                    using var cmd2 = connB.CreateCommand();
                    cmd2.Transaction = txB;
                    cmd2.CommandText = "UPDATE Angajati SET salariu = salariu + 5 WHERE id_angajat = @id";
                    cmd2.Parameters.AddWithValue("@id", id1);
                    await cmd2.ExecuteNonQueryAsync();
                    await txB.CommitAsync();
                    log.AppendLine("Tranzactia B: a blocat randul id=1 si COMMITTED");
                }
                catch (SqlException ex) when (ex.Number == 1205)
                {
                    log.AppendLine("Tranzactia B: VICTIMA DEADLOCK! SQL Server a anulat aceasta tranzactie.");
                }
                catch (Exception ex)
                {
                    log.AppendLine($"Tranzactia B: Eroare - {ex.Message}");
                }
            });

            await Task.WhenAll(taskA, taskB);

            log.AppendLine();
            log.AppendLine($"[FINAL] Salariu id=1: {await ReadSalariuAsync(id1)}, Salariu id=2: {await ReadSalariuAsync(id2)}");
            log.AppendLine();
            log.AppendLine("CONCLUZIE: SQL Server (eroare 1205) a detectat deadlock-ul si a ales o victima.");
            log.AppendLine("PREVENTIE: Achizitionati lock-urile intotdeauna in aceeasi ordine globala.");

            return log.ToString();
        }

        // ─────────────────────────────────────────────────────────
        //  F. BATCH INSERT COMPARISON
        //  Returneaza BatchInsertResult (log + date pentru grafic)
        // ─────────────────────────────────────────────────────────

        public static async Task<BatchInsertResult> RunBatchInsertComparisonAsync(int total = 5000, int iterations = 3)
        {
            var log = new StringBuilder();
            log.AppendLine("=== COMPARATIE PERFORMANTA BATCH INSERT ===");
            log.AppendLine($"Fiecare abordare insereaza {total} randuri, repetata de {iterations} ori.");
            log.AppendLine();

            string runId = Guid.NewGuid().ToString("N").Substring(0, 8);

            // ── Abordarea 1: Auto-commit per INSERT ──
            async Task<long> RunAutoCommitAsync(string prefix)
            {
                var sw = Stopwatch.StartNew();
                using var conn = data.DatabaseManager.GetConnection();
                await conn.OpenAsync();
                using var cmd = conn.CreateCommand();
                cmd.CommandText = "INSERT INTO Angajati (nume, prenume, functie, salariu) VALUES (@n, @p, @f, @s)";
                cmd.Parameters.Add(new SqlParameter("@n", SqlDbType.NVarChar, 100));
                cmd.Parameters.Add(new SqlParameter("@p", SqlDbType.NVarChar, 100));
                cmd.Parameters.AddWithValue("@f", "BatchTest");
                cmd.Parameters.Add(new SqlParameter("@s", SqlDbType.Decimal));
                for (int i = 0; i < total; i++)
                {
                    cmd.Parameters["@n"].Value = $"Batch{prefix}";
                    cmd.Parameters["@p"].Value = $"A{i}";
                    cmd.Parameters["@s"].Value = 3000m;
                    await cmd.ExecuteNonQueryAsync();
                }
                sw.Stop();
                using var del = conn.CreateCommand();
                del.CommandText = "DELETE FROM Angajati WHERE functie = 'BatchTest'";
                await del.ExecuteNonQueryAsync();
                return sw.ElapsedMilliseconds;
            }

            // ── Abordarea 2: Commit la fiecare 100 ──
            async Task<long> RunBatchedCommitsAsync(string prefix)
            {
                var sw = Stopwatch.StartNew();
                using var conn = data.DatabaseManager.GetConnection();
                await conn.OpenAsync();
                SqlTransaction tx = conn.BeginTransaction();
                try
                {
                    using var cmd = conn.CreateCommand();
                    cmd.Transaction = tx;
                    cmd.CommandText = "INSERT INTO Angajati (nume, prenume, functie, salariu) VALUES (@n, @p, @f, @s)";
                    cmd.Parameters.Add(new SqlParameter("@n", SqlDbType.NVarChar, 100));
                    cmd.Parameters.Add(new SqlParameter("@p", SqlDbType.NVarChar, 100));
                    cmd.Parameters.AddWithValue("@f", "BatchTest");
                    cmd.Parameters.Add(new SqlParameter("@s", SqlDbType.Decimal));
                    for (int i = 0; i < total; i++)
                    {
                        cmd.Parameters["@n"].Value = $"Batch{prefix}";
                        cmd.Parameters["@p"].Value = $"B{i}";
                        cmd.Parameters["@s"].Value = 3000m;
                        await cmd.ExecuteNonQueryAsync();
                        if ((i + 1) % 100 == 0)
                        {
                            await tx.CommitAsync();
                            tx.Dispose();
                            tx = conn.BeginTransaction();
                            cmd.Transaction = tx;
                        }
                    }
                    await tx.CommitAsync();
                }
                catch { await tx.RollbackAsync(); throw; }
                finally { tx.Dispose(); }
                sw.Stop();
                using var del = conn.CreateCommand();
                del.CommandText = "DELETE FROM Angajati WHERE functie = 'BatchTest'";
                await del.ExecuteNonQueryAsync();
                return sw.ElapsedMilliseconds;
            }

            // ── Abordarea 3: O singura tranzactie ──
            async Task<long> RunSingleTransactionAsync(string prefix)
            {
                var sw = Stopwatch.StartNew();
                using var conn = data.DatabaseManager.GetConnection();
                await conn.OpenAsync();
                using var tx = conn.BeginTransaction();
                try
                {
                    using var cmd = conn.CreateCommand();
                    cmd.Transaction = tx;
                    cmd.CommandText = "INSERT INTO Angajati (nume, prenume, functie, salariu) VALUES (@n, @p, @f, @s)";
                    cmd.Parameters.Add(new SqlParameter("@n", SqlDbType.NVarChar, 100));
                    cmd.Parameters.Add(new SqlParameter("@p", SqlDbType.NVarChar, 100));
                    cmd.Parameters.AddWithValue("@f", "BatchTest");
                    cmd.Parameters.Add(new SqlParameter("@s", SqlDbType.Decimal));  
                    for (int i = 0; i < total; i++)
                    {
                        cmd.Parameters["@n"].Value = $"Batch{prefix}";
                        cmd.Parameters["@p"].Value = $"C{i}";
                        cmd.Parameters["@s"].Value = 3000m;
                        await cmd.ExecuteNonQueryAsync();
                    }
                    await tx.CommitAsync();
                }
                catch { await tx.RollbackAsync(); throw; }
                sw.Stop();
                using var del = conn.CreateCommand();
                del.CommandText = "DELETE FROM Angajati WHERE functie = 'BatchTest'";
                await del.ExecuteNonQueryAsync();
                return sw.ElapsedMilliseconds;
            }

            var times1 = new List<long>();
            var times2 = new List<long>();
            var times3 = new List<long>();

            for (int i = 1; i <= iterations; i++)
            {
                string p = $"{runId}_{i}";
                log.AppendLine($"--- Iteratia {i} ---");
                var t1 = await RunAutoCommitAsync(p);
                times1.Add(t1);
                log.AppendLine($"  Abordarea 1 (auto-commit per insert):   {t1} ms");
                var t2 = await RunBatchedCommitsAsync(p);
                times2.Add(t2);
                log.AppendLine($"  Abordarea 2 (commit la fiecare 100):    {t2} ms");
                var t3 = await RunSingleTransactionAsync(p);
                times3.Add(t3);
                log.AppendLine($"  Abordarea 3 (o singura tranzactie):     {t3} ms");
                await Task.Delay(300);
            }

            double avg1 = Math.Round(times1.Average(), 1);
            double avg2 = Math.Round(times2.Average(), 1);
            double avg3 = Math.Round(times3.Average(), 1);

            log.AppendLine();
            log.AppendLine("╔═══════════════════════════════════════════════════════╗");
            log.AppendLine("║              REZULTATE FINALE (medii)                 ║");
            log.AppendLine("╠═══════════════════════════════════════════════════════╣");
            log.AppendLine($"║  Abordarea 1 (auto-commit per insert):   {avg1,8} ms  ║");
            log.AppendLine($"║  Abordarea 2 (commit la fiecare 100):    {avg2,8} ms  ║");
            log.AppendLine($"║  Abordarea 3 (o singura tranzactie):     {avg3,8} ms  ║");
            log.AppendLine("╚═══════════════════════════════════════════════════════╝");
            log.AppendLine();
            log.AppendLine("ANALIZA:");
            log.AppendLine("  Abordarea 1 este cea mai lenta: fiecare INSERT are overhead de commit + disk flush.");
            log.AppendLine("  Abordarea 2 reduce overhead-ul de ~100x fata de abordarea 1.");
            log.AppendLine("  Abordarea 3 este cea mai rapida: un singur commit pentru toate inserturile.");
            log.AppendLine("  Dezavantaj Abordarea 3: daca apare eroare, se pierde tot (rollback complet).");
            log.AppendLine("  Abordarea 2 ofera echilibru bun intre performanta si siguranta datelor.");

            return new BatchInsertResult
            {
                Log = log.ToString(),
                Avg1 = avg1,
                Avg2 = avg2,
                Avg3 = avg3,
                Times1 = times1,
                Times2 = times2,
                Times3 = times3
            };
        }
        // ─────────────────────────────────────────────────────────
        //  A. SOLUTIE DIRTY READ → READ COMMITTED
        // ─────────────────────────────────────────────────────────

        public static async Task<string> RunDirtyReadSolutionAsync()
        {
            var log = new StringBuilder();
            const int id = 1;

            await ResetSalariuAsync(id, 5000m);
            log.AppendLine("=== SOLUTIE DIRTY READ: READ COMMITTED ===");
            log.AppendLine($"[INITIAL] Salariu angajat id=1 = {await ReadSalariuAsync(id)}");
            log.AppendLine();
            log.AppendLine("Tranzactia A modifica salariul la 10000 dar NU face commit.");
            log.AppendLine("Tranzactia B foloseste READ COMMITTED => blocheaza pana A face commit/rollback.");
            log.AppendLine();

            using var connA = data.DatabaseManager.GetConnection();
            await connA.OpenAsync();
            using var txA = connA.BeginTransaction(IsolationLevel.ReadCommitted);

            using var cmdA = connA.CreateCommand();
            cmdA.Transaction = txA;
            cmdA.CommandText = "UPDATE Angajati SET salariu = @s WHERE id_angajat = @id";
            cmdA.Parameters.AddWithValue("@s", 10000m);
            cmdA.Parameters.AddWithValue("@id", id);
            await cmdA.ExecuteNonQueryAsync();
            log.AppendLine("Tranzactia A: salariu = 10000 (NECOMIS).");

            // B incearca sa citeasca — va astepta lock-ul lui A
            var taskB = Task.Run(async () =>
            {
                using var connB = data.DatabaseManager.GetConnection();
                await connB.OpenAsync();
                // READ COMMITTED: nu citeste date necomise
                using var txB = connB.BeginTransaction(IsolationLevel.ReadCommitted);
                using var cmdB = connB.CreateCommand();
                cmdB.Transaction = txB;
                cmdB.CommandText = "SELECT salariu FROM Angajati WHERE id_angajat = @id";
                cmdB.Parameters.AddWithValue("@id", id);
                var result = await cmdB.ExecuteScalarAsync();
                var val = result == DBNull.Value || result == null ? 0m : Convert.ToDecimal(result);
                log.AppendLine($"Tranzactia B (READ COMMITTED): a citit salariul = {val}  <-- valoare COMISA, corecta!");
                await txB.CommitAsync();
            });

            await Task.Delay(500);
            await txA.RollbackAsync();
            log.AppendLine("Tranzactia A: ROLLBACK — B va citi acum valoarea originala.");
            await taskB;

            log.AppendLine();
            log.AppendLine($"[FINAL] Salariu committed = {await ReadSalariuAsync(id)}");
            log.AppendLine();
            log.AppendLine("CONCLUZIE: READ COMMITTED garanteaza ca B citeste numai date comise.");
            log.AppendLine("           Mecanismul: shared lock pe durata citirii, blocat de exclusive lock-ul lui A.");

            return log.ToString();
        }

        // ─────────────────────────────────────────────────────────
        //  B. SOLUTIE NON-REPEATABLE READ → REPEATABLE READ
        // ─────────────────────────────────────────────────────────

        public static async Task<string> RunNonRepeatableReadSolutionAsync()
        {
            var log = new StringBuilder();
            const int id = 1;

            await ResetSalariuAsync(id, 5000m);
            log.AppendLine("=== SOLUTIE NON-REPEATABLE READ: REPEATABLE READ ===");
            log.AppendLine($"[INITIAL] Salariu angajat id=1 = {await ReadSalariuAsync(id)}");
            log.AppendLine();
            log.AppendLine("Tranzactia A citeste cu REPEATABLE READ.");
            log.AppendLine("Dupa prima citire, tine shared lock => tranzactia B nu poate modifica randul.");
            log.AppendLine();

            using var connA = data.DatabaseManager.GetConnection();
            await connA.OpenAsync();
            // REPEATABLE READ: mentine shared lock-urile pe durata intregii tranzactii
            using var txA = connA.BeginTransaction(IsolationLevel.RepeatableRead);

            using var cmdA = connA.CreateCommand();
            cmdA.Transaction = txA;
            cmdA.CommandText = "SELECT salariu FROM Angajati WHERE id_angajat = @id";
            cmdA.Parameters.AddWithValue("@id", id);
            var first = await cmdA.ExecuteScalarAsync();
            var firstVal = first == DBNull.Value || first == null ? 0m : Convert.ToDecimal(first);
            log.AppendLine($"Tranzactia A: Prima citire = {firstVal}");
            log.AppendLine("Tranzactia A: tine acum shared lock pe randul id=1...");

            // B incearca UPDATE — va fi blocata
            var taskB = Task.Run(async () =>
            {
                log.AppendLine("Tranzactia B: incearca sa modifice salariul la 12000...");
                using var connB = data.DatabaseManager.GetConnection();
                await connB.OpenAsync();
                using var txB = connB.BeginTransaction(IsolationLevel.ReadCommitted);
                using var cmdB = connB.CreateCommand();
                cmdB.Transaction = txB;
                cmdB.CommandText = "UPDATE Angajati SET salariu = @s WHERE id_angajat = @id";
                cmdB.Parameters.AddWithValue("@s", 12000m);
                cmdB.Parameters.AddWithValue("@id", id);
                await cmdB.ExecuteNonQueryAsync(); // blocata pana A face commit
                await txB.CommitAsync();
                log.AppendLine("Tranzactia B: a putut face commit DUPA ce A a eliberat lock-ul.");
            });

            await Task.Delay(600);

            // A reciteste — aceeasi valoare garantata
            var second = await cmdA.ExecuteScalarAsync();
            var secondVal = second == DBNull.Value || second == null ? 0m : Convert.ToDecimal(second);
            log.AppendLine($"Tranzactia A: A doua citire = {secondVal}  <-- IDENTICA cu prima!");

            await txA.CommitAsync();
            log.AppendLine("Tranzactia A: COMMIT — lock-ul eliberat, B poate continua.");
            await taskB;

            log.AppendLine();
            log.AppendLine($"[FINAL] Salariu dupa ambele commit-uri = {await ReadSalariuAsync(id)}");
            log.AppendLine();
            log.AppendLine("CONCLUZIE: REPEATABLE READ garanteaza lecturi identice in aceeasi tranzactie.");
            log.AppendLine("           Shared lock-urile sunt eliberate numai la commit, nu dupa fiecare citire.");

            return log.ToString();
        }

        // ─────────────────────────────────────────────────────────
        //  C. SOLUTIE PHANTOM READ → SERIALIZABLE
        // ─────────────────────────────────────────────────────────

        public static async Task<string> RunPhantomReadSolutionAsync()
        {
            var log = new StringBuilder();
            const string functieTest = "Vanzator";

            log.AppendLine("=== SOLUTIE PHANTOM READ: SERIALIZABLE ===");
            log.AppendLine($"[INITIAL] Numar angajati cu functia '{functieTest}' = {await CountByFunctieAsync(functieTest)}");
            log.AppendLine();
            log.AppendLine("Tranzactia A foloseste SERIALIZABLE => range lock pe WHERE functie='Vanzator'.");
            log.AppendLine("Tranzactia B nu poate insera randuri noi care s-ar potrivi cu acel range.");
            log.AppendLine();

            using var connA = data.DatabaseManager.GetConnection();
            await connA.OpenAsync();
            // SERIALIZABLE: range locks => previne insertii in range-ul interogat
            using var txA = connA.BeginTransaction(IsolationLevel.Serializable);

            using var cmdA = connA.CreateCommand();
            cmdA.Transaction = txA;
            cmdA.CommandText = "SELECT COUNT(*) FROM Angajati WHERE functie = @f";
            cmdA.Parameters.AddWithValue("@f", functieTest);
            var first = Convert.ToInt32(await cmdA.ExecuteScalarAsync());
            log.AppendLine($"Tranzactia A: Prima numaratoare = {first}");
            log.AppendLine("Tranzactia A: range lock activ pentru functie='Vanzator'...");

            string phantomPrenume = "PhantomSolution";
            var taskB = Task.Run(async () =>
            {
                log.AppendLine("Tranzactia B: incearca sa insereze un Vanzator nou...");
                using var connB = data.DatabaseManager.GetConnection();
                await connB.OpenAsync();
                using var txB = connB.BeginTransaction(IsolationLevel.ReadCommitted);
                using var cmdB = connB.CreateCommand();
                cmdB.Transaction = txB;
                cmdB.CommandText = @"INSERT INTO Angajati (nume, prenume, functie, salariu)
                             VALUES ('Phantom', @p, @f, 3000)";
                cmdB.Parameters.AddWithValue("@p", phantomPrenume);
                cmdB.Parameters.AddWithValue("@f", functieTest);
                await cmdB.ExecuteNonQueryAsync(); // blocata de range lock-ul lui A
                await txB.CommitAsync();
                log.AppendLine("Tranzactia B: INSERT reusit DUPA ce A a eliberat range lock-ul.");
            });

            await Task.Delay(600);

            var second = Convert.ToInt32(await cmdA.ExecuteScalarAsync());
            log.AppendLine($"Tranzactia A: A doua numaratoare = {second}  <-- IDENTICA, fara fantome!");

            await txA.CommitAsync();
            log.AppendLine("Tranzactia A: COMMIT — range lock eliberat.");
            await taskB;

            // Curatare
            using var connClean = data.DatabaseManager.GetConnection();
            await connClean.OpenAsync();
            using var cmdClean = connClean.CreateCommand();
            cmdClean.CommandText = "DELETE FROM Angajati WHERE prenume = @p AND nume = 'Phantom'";
            cmdClean.Parameters.AddWithValue("@p", phantomPrenume);
            await cmdClean.ExecuteNonQueryAsync();

            log.AppendLine();
            log.AppendLine($"Prima numaratoare: {first}  |  A doua numaratoare: {second}");
            log.AppendLine();
            log.AppendLine("CONCLUZIE: SERIALIZABLE previne phantom reads prin range locks pe predicatul WHERE.");
            log.AppendLine("           Orice INSERT/DELETE in range-ul activ este blocat pe durata tranzactiei A.");
            log.AppendLine("[CURATARE] Angajatul phantom a fost sters.");

            return log.ToString();
        }

        // ─────────────────────────────────────────────────────────
        //  D. SOLUTIE LOST UPDATE → UPDLOCK (pessimistic)
        //     + varianta optimista cu rowversion
        // ─────────────────────────────────────────────────────────

        public static async Task<string> RunLostUpdateSolutionAsync()
        {
            var log = new StringBuilder();
            const int id = 1;

            await ResetSalariuAsync(id, 5000m);
            log.AppendLine("=== SOLUTIE LOST UPDATE: SELECT WITH (UPDLOCK) ===");
            log.AppendLine($"[INITIAL] Salariu angajat id=1 = {await ReadSalariuAsync(id)}");
            log.AppendLine();
            log.AppendLine("Ambele tranzactii folosesc SELECT ... WITH (UPDLOCK).");
            log.AppendLine("Prima care citeste obtine update lock => a doua asteapta.");
            log.AppendLine("Astfel ambele update-uri sunt aplicate in serie, nu se pierde niciunul.");
            log.AppendLine();

            var taskA = Task.Run(async () =>
            {
                using var connA = data.DatabaseManager.GetConnection();
                await connA.OpenAsync();
                using var txA = connA.BeginTransaction(IsolationLevel.ReadCommitted);

                // UPDLOCK: converteste shared lock in update lock => bloca ceilalti cititori cu UPDLOCK
                using var cmdRead = connA.CreateCommand();
                cmdRead.Transaction = txA;
                cmdRead.CommandText = "SELECT salariu FROM Angajati WITH (UPDLOCK) WHERE id_angajat = @id";
                cmdRead.Parameters.AddWithValue("@id", id);
                var read = Convert.ToDecimal(await cmdRead.ExecuteScalarAsync());
                log.AppendLine($"Tranzactia A: a citit (cu UPDLOCK) salariul = {read}");
                var newSal = read + 1000m;

                await Task.Delay(600);

                using var cmdUpd = connA.CreateCommand();
                cmdUpd.Transaction = txA;
                cmdUpd.CommandText = "UPDATE Angajati SET salariu = @s WHERE id_angajat = @id";
                cmdUpd.Parameters.AddWithValue("@s", newSal);
                cmdUpd.Parameters.AddWithValue("@id", id);
                await cmdUpd.ExecuteNonQueryAsync();
                await txA.CommitAsync();
                log.AppendLine($"Tranzactia A: a scris salariul = {newSal} si COMMITTED");
            });

            var taskB = Task.Run(async () =>
            {
                await Task.Delay(100);
                using var connB = data.DatabaseManager.GetConnection();
                await connB.OpenAsync();
                using var txB = connB.BeginTransaction(IsolationLevel.ReadCommitted);

                log.AppendLine("Tranzactia B: asteapta UPDLOCK eliberat de A...");
                using var cmdRead = connB.CreateCommand();
                cmdRead.Transaction = txB;
                // B asteapta lock-ul lui A
                cmdRead.CommandText = "SELECT salariu FROM Angajati WITH (UPDLOCK) WHERE id_angajat = @id";
                cmdRead.Parameters.AddWithValue("@id", id);
                var read = Convert.ToDecimal(await cmdRead.ExecuteScalarAsync());
                log.AppendLine($"Tranzactia B: a citit (dupa A) salariul = {read}  <-- valoarea deja actualizata de A!");
                var newSal = read + 500m;

                using var cmdUpd = connB.CreateCommand();
                cmdUpd.Transaction = txB;
                cmdUpd.CommandText = "UPDATE Angajati SET salariu = @s WHERE id_angajat = @id";
                cmdUpd.Parameters.AddWithValue("@s", newSal);
                cmdUpd.Parameters.AddWithValue("@id", id);
                await cmdUpd.ExecuteNonQueryAsync();
                await txB.CommitAsync();
                log.AppendLine($"Tranzactia B: a scris salariul = {newSal} si COMMITTED");
            });

            await Task.WhenAll(taskA, taskB);

            var final = await ReadSalariuAsync(id);
            log.AppendLine();
            log.AppendLine($"[FINAL] Salariu dupa ambele commit-uri = {final}");
            log.AppendLine($"        Asteptat: 5000 + 1000 + 500 = 6500");
            log.AppendLine();

            if (final == 6500m)
                log.AppendLine("REZULTAT: Ambele actualizari aplicate corect — nicio pierdere!");
            else
                log.AppendLine($"REZULTAT: Valoare finala {final} (verificati ordinea executiei).");

            log.AppendLine();
            log.AppendLine("CONCLUZIE: WITH (UPDLOCK) forteaza serializarea citire-modificare-scriere.");
            log.AppendLine("           Alternativa optimista: adaugati coloana rowversion si verificati");
            log.AppendLine("           ca valoarea n-a schimbat intre SELECT si UPDATE (retry daca da).");

            return log.ToString();
        }

        // ─────────────────────────────────────────────────────────
        //  E. SOLUTIE DEADLOCK → Ordine globala consistenta
        // ─────────────────────────────────────────────────────────

        public static async Task<string> RunDeadlockSolutionAsync()
        {
            var log = new StringBuilder();
            const int id1 = 1;
            const int id2 = 2;

            await ResetSalariuAsync(id1, 5000m);
            await ResetSalariuAsync(id2, 4500m);

            log.AppendLine("=== SOLUTIE DEADLOCK: ORDINE GLOBALA CONSISTENTA ===");
            log.AppendLine($"[INITIAL] Salariu id=1: {await ReadSalariuAsync(id1)}, Salariu id=2: {await ReadSalariuAsync(id2)}");
            log.AppendLine();
            log.AppendLine("Ambele tranzactii achizitioneaza lock-urile in ACEEASI ordine: id=1 intai, id=2 al doilea.");
            log.AppendLine("=> Nu mai exista ciclu de asteptare => imposibil deadlock.");
            log.AppendLine();

            // Regula: intotdeauna lock id mai mic primul
            var taskA = Task.Run(async () =>
            {
                using var connA = data.DatabaseManager.GetConnection();
                await connA.OpenAsync();
                using var txA = connA.BeginTransaction(IsolationLevel.ReadCommitted);
                try
                {
                    // Ordine: id1 (1) -> id2 (2)
                    using var cmd1 = connA.CreateCommand();
                    cmd1.Transaction = txA;
                    cmd1.CommandText = "UPDATE Angajati SET salariu = salariu + 10 WHERE id_angajat = @id";
                    cmd1.Parameters.AddWithValue("@id", id1);
                    await cmd1.ExecuteNonQueryAsync();
                    log.AppendLine("Tranzactia A: a blocat randul id=1");

                    await Task.Delay(200); // lasa B sa porneasca

                    using var cmd2 = connA.CreateCommand();
                    cmd2.Transaction = txA;
                    cmd2.CommandText = "UPDATE Angajati SET salariu = salariu + 10 WHERE id_angajat = @id";
                    cmd2.Parameters.AddWithValue("@id", id2);
                    await cmd2.ExecuteNonQueryAsync();
                    await txA.CommitAsync();
                    log.AppendLine("Tranzactia A: a blocat id=2 si COMMITTED (fara deadlock!)");
                }
                catch (Exception ex)
                {
                    log.AppendLine($"Tranzactia A: Eroare neasteptata — {ex.Message}");
                    await txA.RollbackAsync();
                }
            });

            var taskB = Task.Run(async () =>
            {
                await Task.Delay(100);
                using var connB = data.DatabaseManager.GetConnection();
                await connB.OpenAsync();
                using var txB = connB.BeginTransaction(IsolationLevel.ReadCommitted);
                try
                {
                    // Ordine: id1 (1) -> id2 (2)  — ACEEASI ca A, nu id2 -> id1!
                    log.AppendLine("Tranzactia B: incearca id=1 (asteapta dupa A)...");
                    using var cmd1 = connB.CreateCommand();
                    cmd1.Transaction = txB;
                    cmd1.CommandText = "UPDATE Angajati SET salariu = salariu + 5 WHERE id_angajat = @id";
                    cmd1.Parameters.AddWithValue("@id", id1);
                    await cmd1.ExecuteNonQueryAsync(); // asteapta A sa elibereze id1
                    log.AppendLine("Tranzactia B: a obtinut id=1");

                    using var cmd2 = connB.CreateCommand();
                    cmd2.Transaction = txB;
                    cmd2.CommandText = "UPDATE Angajati SET salariu = salariu + 5 WHERE id_angajat = @id";
                    cmd2.Parameters.AddWithValue("@id", id2);
                    await cmd2.ExecuteNonQueryAsync();
                    await txB.CommitAsync();
                    log.AppendLine("Tranzactia B: a blocat id=2 si COMMITTED (fara deadlock!)");
                }
                catch (Exception ex)
                {
                    log.AppendLine($"Tranzactia B: Eroare neasteptata — {ex.Message}");
                    await txB.RollbackAsync();
                }
            });

            await Task.WhenAll(taskA, taskB);

            log.AppendLine();
            log.AppendLine($"[FINAL] Salariu id=1: {await ReadSalariuAsync(id1)}, Salariu id=2: {await ReadSalariuAsync(id2)}");
            log.AppendLine($"        Asteptat id=1: 5015, Asteptat id=2: 4510");
            log.AppendLine();
            log.AppendLine("CONCLUZIE: Ordinea globala consistenta (intotdeauna id_mic -> id_mare)");
            log.AppendLine("           elimina posibilitatea unui ciclu de asteptare.");
            log.AppendLine("           Alternativa: SET DEADLOCK_PRIORITY LOW + retry logic in aplicatie.");

            return log.ToString();
        }
    }
}

