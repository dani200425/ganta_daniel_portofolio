﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace LENSAmanager.data
{
    internal class DatabaseManager
    {
        public static SqlConnection GetConnection()
        {
            var builder = new SqlConnectionStringBuilder
            {
                DataSource = @".\SQLEXPRESS",       // or "DESKTOP-ADTDH9U\\SQLEXPRESS"
                InitialCatalog = "LENSA",
                IntegratedSecurity = true,
                TrustServerCertificate = true
            };
            return new SqlConnection(builder.ConnectionString);
        }
    }
}
