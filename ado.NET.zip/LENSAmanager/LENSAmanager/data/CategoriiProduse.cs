﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LENSAmanager.data
{
    internal class Categorii_Produse
    {
        public int id_categorie { get; set; }
        public string denumire { get; set; } = string.Empty;
    }
}
