﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace LENSAmanager.data
{
    // Repository pentru accesul la tabelul Produse din baza de date
    // Această clasă conține metode CRUD (Create, Read, Update, Delete)
    internal static class ProduseRepository
    {
        // Metodă care returnează toate produsele din tabelul Produse
        public static async Task<List<Produse>> GetAllAsync()
        {
            // Lista în care vom salva produsele citite din baza de date
            var list = new List<Produse>();

            // Creăm conexiunea folosind DatabaseManager
            using var conn = DatabaseManager.GetConnection();

            // Interogare SQL pentru a selecta produsele
            const string sql = "SELECT id_produs, nume_produs FROM Produse";

            // Creăm comanda SQL
            using var cmd = new SqlCommand(sql, conn);

            // Deschidem conexiunea la baza de date
            await conn.OpenAsync();

            // Executăm interogarea și obținem un SqlDataReader
            using var rdr = await cmd.ExecuteReaderAsync();

            // Parcurgem fiecare rând din rezultatul interogării
            while (await rdr.ReadAsync())
            {
                // Creăm un obiect Produse și îl adăugăm în listă
                list.Add(new Produse
                {
                    // Citim valorile din coloanele bazei de date
                    id_produs = rdr.GetInt32(0),

                    // Verificăm dacă valoarea este NULL înainte de citire
                    nume_produs = rdr.IsDBNull(1) ? string.Empty : rdr.GetString(1)
                });
            }

            // Returnăm lista de produse
            return list;
        }

        // Metodă care returnează produsele dintr-o categorie specifică
        // Este folosită pentru a încărca "child rows" în aplicația Master-Detail
        public static async Task<List<Produse>> GetByCategoryAsync(int idCategorie)
        {
            var list = new List<Produse>();

            using var conn = DatabaseManager.GetConnection();

            // Interogare SQL care selectează produsele după id_categorie
            const string sql = @"
                SELECT id_produs, nume_produs, pret, stoc, id_categorie, id_brand
                FROM Produse
                WHERE id_categorie = @id
                ORDER BY id_produs";

            using var cmd = new SqlCommand(sql, conn);

            // Parametru SQL pentru a evita SQL Injection
            cmd.Parameters.AddWithValue("@id", idCategorie);

            await conn.OpenAsync();

            using var rdr = await cmd.ExecuteReaderAsync();

            // Citim fiecare produs din rezultat
            while (await rdr.ReadAsync())
            {
                list.Add(new Produse
                {
                    // Pentru fiecare coloană verificăm dacă valoarea este NULL
                    id_produs = rdr.IsDBNull(0) ? 0 : rdr.GetInt32(0),
                    nume_produs = rdr.IsDBNull(1) ? string.Empty : rdr.GetString(1),
                    pret = rdr.IsDBNull(2) ? 0m : rdr.GetDecimal(2),
                    stoc = rdr.IsDBNull(3) ? 0 : rdr.GetInt32(3),
                    id_categorie = rdr.IsDBNull(4) ? 0 : rdr.GetInt32(4),
                    id_brand = rdr.IsDBNull(5) ? 0 : rdr.GetInt32(5)
                });
            }

            // Returnăm lista de produse din categoria selectată
            return list;
        }

        // Metodă pentru inserarea unui produs nou în baza de date
        public static async Task<int> InsertAsync(Produse p)
        {
            using var conn = DatabaseManager.GetConnection();

            // Interogare SQL pentru inserarea produsului
            // SCOPE_IDENTITY returnează ID-ul generat automat
            const string sql = @"
                INSERT INTO Produse (nume_produs, pret, stoc, id_categorie, id_brand)
                VALUES (@nume, @pret, @stoc, @idcat, @idbrand);
                SELECT CAST(SCOPE_IDENTITY() AS int);";

            using var cmd = new SqlCommand(sql, conn);

            // Adăugăm parametrii pentru query
            cmd.Parameters.AddWithValue("@nume", p.nume_produs);
            cmd.Parameters.AddWithValue("@pret", p.pret);
            cmd.Parameters.AddWithValue("@stoc", p.stoc);
            cmd.Parameters.AddWithValue("@idcat", p.id_categorie);
            cmd.Parameters.AddWithValue("@idbrand", p.id_brand);

            await conn.OpenAsync();

            // Executăm query-ul și obținem ID-ul noului produs
            var result = await cmd.ExecuteScalarAsync();

            // Returnăm ID-ul sau 0 dacă nu există rezultat
            return result == null || result is DBNull ? 0 : (int)result;
        }

        // Metodă pentru actualizarea unui produs existent
        public static async Task<bool> UpdateAsync(Produse p)
        {
            using var conn = DatabaseManager.GetConnection();

            // Query SQL pentru actualizare
            const string sql = @"
                UPDATE Produse
                SET nume_produs = @nume, pret = @pret, stoc = @stoc, id_categorie = @idcat, id_brand = @idbrand
                WHERE id_produs = @id";

            using var cmd = new SqlCommand(sql, conn);

            // Parametrii pentru actualizare
            cmd.Parameters.AddWithValue("@nume", p.nume_produs);
            cmd.Parameters.AddWithValue("@pret", p.pret);
            cmd.Parameters.AddWithValue("@stoc", p.stoc);
            cmd.Parameters.AddWithValue("@idcat", p.id_categorie);
            cmd.Parameters.AddWithValue("@idbrand", p.id_brand);
            cmd.Parameters.AddWithValue("@id", p.id_produs);

            await conn.OpenAsync();

            // ExecuteNonQuery returnează numărul de rânduri afectate
            var rows = await cmd.ExecuteNonQueryAsync();

            // Dacă este > 0 înseamnă că update-ul a reușit
            return rows > 0;
        }

        // Metodă pentru ștergerea unui produs după ID
        public static async Task<bool> DeleteAsync(int id)
        {
            using var conn = DatabaseManager.GetConnection();

            // Query SQL pentru ștergere
            const string sql = "DELETE FROM Produse WHERE id_produs = @id";

            using var cmd = new SqlCommand(sql, conn);

            // Parametru pentru identificarea produsului
            cmd.Parameters.AddWithValue("@id", id);

            await conn.OpenAsync();

            // Executăm comanda
            var rows = await cmd.ExecuteNonQueryAsync();

            // Dacă s-a șters cel puțin un rând returnăm true
            return rows > 0;
        }
    }
}