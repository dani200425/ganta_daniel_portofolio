﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace LENSAmanager
{
    // Fereastra care afiseaza graficul de comparatie batch insert
    // Foloseste GDI+ (System.Drawing) - nu necesita librarii externe
    internal class BatchChartForm : Form
    {
        private readonly BatchInsertResult _result;

        public BatchChartForm(BatchInsertResult result)
        {
            _result = result;
            Text = "Comparatie Performanta Batch Insert";
            Width = 950;
            Height = 720;
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Color.White;
            MinimumSize = new Size(700, 550);

            // Panel cu graficul (sus)
            var chartPanel = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.White
            };
            chartPanel.Paint += ChartPanel_Paint;
            chartPanel.Resize += (_, __) => chartPanel.Invalidate();

            // TextBox cu log-ul (jos)
            var logBox = new TextBox
            {
                Multiline = true,
                ReadOnly = true,
                Dock = DockStyle.Bottom,
                Height = 180,
                ScrollBars = ScrollBars.Both,
                Font = new Font("Consolas", 8.5f),
                BackColor = Color.FromArgb(245, 245, 245),
                Text = result.Log
            };

            var splitter = new Splitter { Dock = DockStyle.Bottom, Height = 4 };

            Controls.Add(chartPanel);
            Controls.Add(splitter);
            Controls.Add(logBox);
        }

        private void ChartPanel_Paint(object? sender, PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;

            var panel = (Panel)sender!;
            int W = panel.Width;
            int H = panel.Height;

            // Margini
            int marginLeft = 90;
            int marginRight = 30;
            int marginTop = 60;
            int marginBottom = 110;

            int chartW = W - marginLeft - marginRight;
            int chartH = H - marginTop - marginBottom;

            // Culorile barelor
            var colors = new[]
            {
                Color.FromArgb(220, 60, 60),    // rosu - abordarea 1 (cea mai lenta)
                Color.FromArgb(60, 140, 220),   // albastru - abordarea 2
                Color.FromArgb(60, 180, 100)    // verde - abordarea 3 (cea mai rapida)
            };

            string[] labels = { "Auto-commit\n(per insert)", "Commit la\nfiecare 100", "O singura\ntranzactie" };
            double[] avgs = { _result.Avg1, _result.Avg2, _result.Avg3 };
            var allTimes = new List<List<long>> { _result.Times1, _result.Times2, _result.Times3 };

            double maxVal = Math.Max(avgs.Max(), 1);
            // Adaugam 15% spatiu deasupra celei mai inalte bare
            double scale = chartH / (maxVal * 1.15);

            // ── Fundal grafic ──
            g.FillRectangle(new SolidBrush(Color.FromArgb(252, 252, 252)),
                marginLeft, marginTop, chartW, chartH);
            g.DrawRectangle(Pens.LightGray, marginLeft, marginTop, chartW, chartH);

            // ── Linii orizontale de referinta ──
            int gridLines = 5;
            using var gridPen = new Pen(Color.FromArgb(220, 220, 220), 1);
            gridPen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            var labelFont = new Font("Segoe UI", 8f);
            var labelBrush = new SolidBrush(Color.FromArgb(100, 100, 100));

            for (int gi = 0; gi <= gridLines; gi++)
            {
                double val = maxVal * 1.15 * gi / gridLines;
                int y = marginTop + chartH - (int)(val * scale);
                if (y >= marginTop && y <= marginTop + chartH)
                {
                    g.DrawLine(gridPen, marginLeft, y, marginLeft + chartW, y);
                    string valStr = val >= 1000 ? $"{val / 1000:0.#}s" : $"{(int)val}ms";
                    var sz = g.MeasureString(valStr, labelFont);
                    g.DrawString(valStr, labelFont, labelBrush,
                        marginLeft - sz.Width - 5, y - sz.Height / 2);
                }
            }

            // ── Barele principale (medii) ──
            int barCount = 3;
            int groupW = chartW / barCount;
            int barW = (int)(groupW * 0.5);
            int barX0 = marginLeft + (groupW - barW) / 2;

            for (int b = 0; b < barCount; b++)
            {
                int barH = (int)(avgs[b] * scale);
                int x = barX0 + b * groupW;
                int y = marginTop + chartH - barH;

                // Umbra bara
                using var shadowBrush = new SolidBrush(Color.FromArgb(30, 0, 0, 0));
                g.FillRectangle(shadowBrush, x + 3, y + 3, barW, barH);

                // Gradientul barei
                if (barH > 0)
                {
                    using var grad = new System.Drawing.Drawing2D.LinearGradientBrush(
                        new Rectangle(x, y, barW, barH),
                        ControlPaint.Light(colors[b], 0.3f),
                        colors[b],
                        System.Drawing.Drawing2D.LinearGradientMode.Vertical);
                    g.FillRectangle(grad, x, y, barW, barH);
                }

                // Contur bara
                using var barPen = new Pen(ControlPaint.Dark(colors[b], 0.1f), 1.5f);
                g.DrawRectangle(barPen, x, y, barW, barH);

                // Valoare deasupra barei
                string valLabel = avgs[b] >= 1000
                    ? $"{avgs[b] / 1000:0.##}s"
                    : $"{avgs[b]:0}ms";
                var valFont = new Font("Segoe UI", 9f, FontStyle.Bold);
                var valSz = g.MeasureString(valLabel, valFont);
                g.DrawString(valLabel, valFont,
                    new SolidBrush(colors[b]),
                    x + (barW - valSz.Width) / 2,
                    y - valSz.Height - 3);

                // Puncte individuale (fiecare iteratie)
                if (allTimes[b].Count > 0)
                {
                    using var dotBrush = new SolidBrush(Color.FromArgb(180, ControlPaint.Dark(colors[b], 0.2f)));
                    foreach (var t in allTimes[b])
                    {
                        int dotY = marginTop + chartH - (int)(t * scale);
                        int dotX = x + barW / 2;
                        g.FillEllipse(dotBrush, dotX - 4, dotY - 4, 8, 8);
                        g.DrawEllipse(Pens.White, dotX - 4, dotY - 4, 8, 8);
                    }
                }

                // Eticheta bara (jos)
                var axisFont = new Font("Segoe UI", 8.5f, FontStyle.Bold);
                var lines = labels[b].Split('\n');
                int labelY = marginTop + chartH + 10;
                foreach (var line in lines)
                {
                    var lsz = g.MeasureString(line, axisFont);
                    g.DrawString(line, axisFont,
                        new SolidBrush(Color.FromArgb(60, 60, 60)),
                        x + (barW - lsz.Width) / 2, labelY);
                    labelY += (int)lsz.Height + 1;
                }
            }

            // ── Axa Y ──
            using var axisPen = new Pen(Color.FromArgb(180, 180, 180), 1.5f);
            g.DrawLine(axisPen, marginLeft, marginTop, marginLeft, marginTop + chartH);
            g.DrawLine(axisPen, marginLeft, marginTop + chartH, marginLeft + chartW, marginTop + chartH);

            // ── Titlu ──
            var titleFont = new Font("Segoe UI", 13f, FontStyle.Bold);
            string title = "Comparatie Performanta Batch Insert (5000 randuri)";
            var titleSz = g.MeasureString(title, titleFont);
            g.DrawString(title, titleFont, new SolidBrush(Color.FromArgb(40, 40, 80)),
                (W - titleSz.Width) / 2, 12);

            // ── Subtitlu axa Y ──
            var axisLabelFont = new Font("Segoe UI", 8f);
            g.TranslateTransform(14, marginTop + chartH / 2);
            g.RotateTransform(-90);
            g.DrawString("Timp (ms)", axisLabelFont, labelBrush, 0, 0);
            g.ResetTransform();

            // ── Legenda iteratii ──
            var legendFont = new Font("Segoe UI", 8f);
            string legendText = "● puncte = valori per iteratie    ▬ bara = medie";
            var legendSz = g.MeasureString(legendText, legendFont);
            g.DrawString(legendText, legendFont,
                new SolidBrush(Color.FromArgb(130, 130, 130)),
                (W - legendSz.Width) / 2,
                marginTop + chartH + 80);
        }
    }
}