﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LENSAmanager.data
{
    internal class Produse
    {
        public int id_produs { get; set; }
        public string nume_produs { get; set; } = string.Empty;
        public decimal pret { get; set; }
        public int stoc { get; set; }

        // Foreign keys 
        public int id_categorie { get; set; } // FK -> Categorii_Produse.id_categorie
        public int id_brand { get; set; }     // FK -> Brands.id_brand
    }
}
