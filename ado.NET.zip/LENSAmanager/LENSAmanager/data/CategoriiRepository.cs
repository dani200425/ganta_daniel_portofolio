﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace LENSAmanager.data
{
    // Clasă repository responsabilă pentru accesul la datele din tabela Categorii_Produse
    // Separă logica bazei de date de codul UI (respectă arhitectura cerută în proiect)
    internal static class CategoriiRepository
    {
        // Metodă asincronă care returnează toate categoriile din baza de date
        public static async Task<List<Categorii_Produse>> GetAllAsync()
        {
            // Listă în care vor fi salvate categoriile citite din baza de date
            var list = new List<Categorii_Produse>();

            // Se obține conexiunea la baza de date folosind DatabaseManager
            // using asigură închiderea automată a conexiunii
            using var conn = DatabaseManager.GetConnection();

            // Interogare SQL care selectează toate categoriile
            const string sql = "SELECT id_categorie, denumire FROM Categorii_Produse"; // <- adjust to your actual table/columns

            // Crearea obiectului SqlCommand care va executa interogarea
            using var cmd = new SqlCommand(sql, conn);

            // Deschiderea conexiunii la baza de date în mod asincron
            await conn.OpenAsync();

            // Executarea interogării și obținerea unui SqlDataReader pentru citirea rezultatelor
            using var rdr = await cmd.ExecuteReaderAsync();

            // Se parcurg rândurile returnate de interogare
            while (await rdr.ReadAsync())
            {
                // Pentru fiecare rând se creează un obiect Categorii_Produse
                // și se adaugă în listă
                list.Add(new Categorii_Produse
                {
                    // Se citește id-ul categoriei din prima coloană
                    id_categorie = rdr.GetInt32(0),

                    // Se citește denumirea categoriei
                    // Dacă valoarea este NULL în baza de date, se folosește string gol
                    denumire = rdr.IsDBNull(1) ? string.Empty : rdr.GetString(1)
                });
            }

            // Lista cu toate categoriile este returnată către apelant (de obicei UI)
            return list;
        }
    }
}