﻿using LENSAmanager.data;
using Microsoft.Data.SqlClient;
using System.ComponentModel;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;
using System;

namespace LENSAmanager
{
    public partial class Form1 : Form
    {
        private readonly DataGridView _parentGrid;
        private readonly DataGridView _childGrid;
        private BindingList<Categorii_Produse> _parentBinding;
        private BindingList<Produse> _childBinding;

        private TextBox txtNume;
        private TextBox txtPret;
        private TextBox txtStoc;
        private TextBox txtBrand;
        private int _editingId = 0;
        private Button btnRefresh;

        public Form1()
        {
            InitializeComponent();
            btnAdd.Visible = false;
            btnSave.Visible = false;
            btnDelete.Visible = false;
            btnClear.Visible = false;

            _parentGrid = dataGridView1;

            _childGrid = new DataGridView
            {
                Dock = DockStyle.Fill,
                AutoGenerateColumns = true,
                ReadOnly = true,
                AllowUserToAddRows = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };
            _childGrid.SelectionChanged += ChildGrid_SelectionChanged;

            var split = new SplitContainer
            {
                Dock = DockStyle.Fill,
                Orientation = Orientation.Vertical,
                SplitterDistance = Width / 2
            };

            Controls.Remove(_parentGrid);
            split.Panel1.Controls.Add(_parentGrid);
            split.Panel2.Controls.Add(_childGrid);
            Controls.Add(split);

            _parentGrid.Dock = DockStyle.Fill;
            _parentGrid.AutoGenerateColumns = true;
            _parentGrid.ReadOnly = true;
            _parentGrid.AllowUserToAddRows = false;
            _parentGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            _parentGrid.SelectionChanged += async (_, __) => await OnParentSelectionChangedAsync();

            this.Shown += async (_, __) => await LoadParentAsync();

            // ── Editor panel ──
            var editorPanel = new Panel { Dock = DockStyle.Bottom, Height = 160 };
            var flow = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = true,
                AutoSize = false
            };

            txtNume = new TextBox { Width = 180 };
            txtPret = new TextBox { Width = 80 };
            txtStoc = new TextBox { Width = 60 };
            txtBrand = new TextBox { Width = 60 };

            btnAdd = new Button { Text = "Add" };
            btnSave = new Button { Text = "Save" };
            btnDelete = new Button { Text = "Delete" };
            btnClear = new Button { Text = "Clear" };
            btnRefresh = new Button { Text = "Refresh" };

            btnAdd.Click += async (_, __) => await BtnAdd_ClickAsync();
            btnSave.Click += async (_, __) => await BtnSave_ClickAsync();
            btnDelete.Click += async (_, __) => await BtnDelete_ClickAsync();
            btnClear.Click += (_, __) => ClearEditor();
            btnRefresh.Click += async (_, __) => await RefreshDataAsync();

            // ── Butoane demo (probleme) ──
            var btnDirtyDemo = new Button { Text = "Dirty Read ⚠", Width = 130 };
            var btnNonRepeatableDemo = new Button { Text = "Non-Repeatable ⚠", Width = 145 };
            var btnPhantomDemo = new Button { Text = "Phantom Read ⚠", Width = 130 };
            var btnLostUpdateDemo = new Button { Text = "Lost Update ⚠", Width = 120 };
            var btnDeadlockDemo = new Button { Text = "Deadlock ⚠", Width = 105 };

            // ── Butoane solutii ──
            var green = Color.FromArgb(198, 235, 198);
            var btnDirtyFix = new Button { Text = "Dirty Read ✔", Width = 130, BackColor = green };
            var btnNonRepeatableFix = new Button { Text = "Non-Repeatable ✔", Width = 145, BackColor = green };
            var btnPhantomFix = new Button { Text = "Phantom Read ✔", Width = 130, BackColor = green };
            var btnLostUpdateFix = new Button { Text = "Lost Update ✔", Width = 120, BackColor = green };
            var btnDeadlockFix = new Button { Text = "Deadlock ✔", Width = 105, BackColor = green };

            var btnBatchCompare = new Button { Text = "Batch Insert Compare", Width = 160 };

            // ── Handlere demo ──
            btnDirtyDemo.Click += async (_, __) => await RunAndShow(TransactionDemos.RunDirtyReadDemoAsync);
            btnNonRepeatableDemo.Click += async (_, __) => await RunAndShow(TransactionDemos.RunNonRepeatableReadDemoAsync);
            btnPhantomDemo.Click += async (_, __) => await RunAndShow(TransactionDemos.RunPhantomReadDemoAsync);
            btnLostUpdateDemo.Click += async (_, __) => await RunAndShow(TransactionDemos.RunLostUpdateDemoAsync);
            btnDeadlockDemo.Click += async (_, __) => await RunAndShow(TransactionDemos.RunDeadlockDemoAsync);

            // ── Handlere solutii ──
            btnDirtyFix.Click += async (_, __) => await RunAndShow(TransactionDemos.RunDirtyReadSolutionAsync);
            btnNonRepeatableFix.Click += async (_, __) => await RunAndShow(TransactionDemos.RunNonRepeatableReadSolutionAsync);
            btnPhantomFix.Click += async (_, __) => await RunAndShow(TransactionDemos.RunPhantomReadSolutionAsync);
            btnLostUpdateFix.Click += async (_, __) => await RunAndShow(TransactionDemos.RunLostUpdateSolutionAsync);
            btnDeadlockFix.Click += async (_, __) => await RunAndShow(TransactionDemos.RunDeadlockSolutionAsync);

            btnBatchCompare.Click += async (_, __) => await RunBatchAndShowChartAsync();

            // ── Layout ──
            flow.Controls.AddRange(new Control[] {
                new Label { Text = "Nume:",    AutoSize = true, Margin = new Padding(4,6,2,0) }, txtNume,
                new Label { Text = "Pret:",    AutoSize = true, Margin = new Padding(4,6,2,0) }, txtPret,
                new Label { Text = "Stoc:",    AutoSize = true, Margin = new Padding(4,6,2,0) }, txtStoc,
                new Label { Text = "BrandId:", AutoSize = true, Margin = new Padding(4,6,2,0) }, txtBrand,
                btnAdd, btnSave, btnDelete, btnClear, btnRefresh,

                new Label { Text = "│ Demos ⚠:", AutoSize = true, Margin = new Padding(6,6,2,0),
                            ForeColor = Color.FromArgb(180,60,60), Font = new Font("Segoe UI", 8.5f, FontStyle.Bold) },
                btnDirtyDemo, btnNonRepeatableDemo, btnPhantomDemo, btnLostUpdateDemo, btnDeadlockDemo,

                new Label { Text = "│ Solutii ✔:", AutoSize = true, Margin = new Padding(6,6,2,0),
                            ForeColor = Color.FromArgb(40,130,60), Font = new Font("Segoe UI", 8.5f, FontStyle.Bold) },
                btnDirtyFix, btnNonRepeatableFix, btnPhantomFix, btnLostUpdateFix, btnDeadlockFix,

                new Label { Text = "│", AutoSize = true, Margin = new Padding(6,6,2,0) },
                btnBatchCompare
            });

            editorPanel.Controls.Add(flow);
            split.Panel2.Controls.Add(editorPanel);
            editorPanel.BringToFront();
        }

        // ── Helpers pentru rularea demo-urilor ──

        private async Task RunAndShow(Func<Task<string>> demo)
        {
            try
            {
                var result = await demo();
                using var dlg = new Form { Width = 900, Height = 700, Text = "Demo output" };
                var tb = new TextBox
                {
                    Multiline = true,
                    ReadOnly = true,
                    Dock = DockStyle.Fill,
                    ScrollBars = ScrollBars.Both,
                    Font = new Font("Consolas", 9f),
                    Text = result
                };
                dlg.Controls.Add(tb);
                dlg.ShowDialog(this);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Demo failed: {ex.Message}");
            }
        }

        private async Task RunBatchAndShowChartAsync()
        {
            try
            {
                var result = await TransactionDemos.RunBatchInsertComparisonAsync(5000, 3);
                using var chartForm = new BatchChartForm(result);
                chartForm.ShowDialog(this);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Demo failed: {ex.Message}");
            }
        }

        // ── CRUD ──

        private async Task BtnAdd_ClickAsync()
        {
            try
            {
                if (_parentGrid.SelectedRows.Count == 0)
                { MessageBox.Show("Selecteaza o categorie."); return; }

                if (!decimal.TryParse(txtPret.Text, out decimal pret) || pret <= 0m)
                { MessageBox.Show("Pret invalid (trebuie sa fie > 0)."); return; }

                if (!int.TryParse(txtStoc.Text, out int stoc) || stoc < 0)
                { MessageBox.Show("Stoc invalid (trebuie sa fie >= 0)."); return; }

                if (!int.TryParse(txtBrand.Text, out int brandId))
                { MessageBox.Show("BrandId invalid."); return; }

                var categorie = (Categorii_Produse)_parentGrid.SelectedRows[0].DataBoundItem;
                var produs = new Produse
                {
                    nume_produs = txtNume.Text,
                    pret = pret,
                    stoc = stoc,
                    id_brand = brandId,
                    id_categorie = categorie.id_categorie
                };

                int newId = await ProduseRepository.InsertAsync(produs);
                produs.id_produs = newId;
                _childBinding?.Add(produs);
                ClearEditor();
                MessageBox.Show("Produs adaugat cu succes!");
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private async Task BtnSave_ClickAsync()
        {
            try
            {
                if (_editingId == 0)
                { MessageBox.Show("Selecteaza un produs pentru editare."); return; }

                if (!decimal.TryParse(txtPret.Text, out decimal pret) || pret <= 0m)
                { MessageBox.Show("Pret invalid (trebuie sa fie > 0)."); return; }

                if (!int.TryParse(txtStoc.Text, out int stoc) || stoc < 0)
                { MessageBox.Show("Stoc invalid (trebuie sa fie >= 0)."); return; }

                if (!int.TryParse(txtBrand.Text, out int brandId))
                { MessageBox.Show("BrandId invalid."); return; }

                var categorie = (Categorii_Produse)_parentGrid.SelectedRows[0].DataBoundItem;
                var produs = new Produse
                {
                    id_produs = _editingId,
                    nume_produs = txtNume.Text,
                    pret = pret,
                    stoc = stoc,
                    id_brand = brandId,
                    id_categorie = categorie.id_categorie
                };

                bool success = await ProduseRepository.UpdateAsync(produs);
                if (success)
                {
                    await LoadChildAsync(categorie.id_categorie);
                    ClearEditor();
                    MessageBox.Show("Produs actualizat!");
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private async Task BtnDelete_ClickAsync()
        {
            try
            {
                if (_childGrid.SelectedRows.Count == 0)
                { MessageBox.Show("Selecteaza un produs."); return; }

                var produs = (Produse)_childGrid.SelectedRows[0].DataBoundItem;
                if (MessageBox.Show("Sigur vrei sa stergi produsul?", "Confirmare",
                        MessageBoxButtons.YesNo) != DialogResult.Yes) return;

                bool success = await ProduseRepository.DeleteAsync(produs.id_produs);
                if (success)
                {
                    _childBinding?.Remove(produs);
                    ClearEditor();
                    MessageBox.Show("Produs sters.");
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void ClearEditor()
        {
            txtNume.Text = txtPret.Text = txtStoc.Text = txtBrand.Text = "";
            _editingId = 0;
        }

        // ── Date ──

        private async Task LoadParentAsync()
        {
            try
            {
                var items = await CategoriiRepository.GetAllAsync();
                _parentBinding = new BindingList<Categorii_Produse>(items);
                _parentGrid.DataSource = null;
                _parentGrid.Columns.Clear();
                _parentGrid.DataSource = _parentBinding;
                _parentGrid.Refresh();
            }
            catch (SqlException ex) { MessageBox.Show($"Database error: {ex.Message}"); }
            catch (Exception ex) { MessageBox.Show($"Unexpected error: {ex.Message}"); }
        }

        private async Task LoadChildAsync(int idCategorie)
        {
            var items = await ProduseRepository.GetByCategoryAsync(idCategorie);
            _childBinding = new BindingList<Produse>(items);
            _childGrid.DataSource = null;
            _childGrid.Columns.Clear();
            _childGrid.DataSource = _childBinding;
            _childGrid.Refresh();
        }

        private async Task OnParentSelectionChangedAsync()
        {
            try
            {
                if (_parentGrid.SelectedRows.Count == 0)
                { _childGrid.DataSource = null; _childGrid.Columns.Clear(); return; }

                var row = _parentGrid.SelectedRows[0];
                if (row?.DataBoundItem is Categorii_Produse cat)
                    await LoadChildAsync(cat.id_categorie);
                else if (row?.Cells["id_categorie"]?.Value is int fallbackId)
                    await LoadChildAsync(fallbackId);
                else
                { _childGrid.DataSource = null; _childGrid.Columns.Clear(); }
            }
            catch (Exception ex) { MessageBox.Show($"Error loading child rows: {ex.Message}"); }
        }

        private async Task RefreshDataAsync()
        {
            try
            {
                await LoadParentAsync();
                if (_parentGrid.SelectedRows.Count > 0
                    && _parentGrid.SelectedRows[0]?.DataBoundItem is Categorii_Produse cat)
                    await LoadChildAsync(cat.id_categorie);
                else
                { _childGrid.DataSource = null; _childGrid.Columns.Clear(); }
            }
            catch (Exception ex) { MessageBox.Show($"Refresh failed: {ex.Message}"); }
        }

        // ── Evenimente grid ──

        private void ChildGrid_SelectionChanged(object sender, EventArgs e)
        {
            if (_childGrid.SelectedRows.Count == 0) return;
            if (_childGrid.SelectedRows[0]?.DataBoundItem is not Produse produs) return;

            txtNume.Text = produs.nume_produs;
            txtPret.Text = produs.pret.ToString();
            txtStoc.Text = produs.stoc.ToString();
            txtBrand.Text = produs.id_brand.ToString();
            _editingId = produs.id_produs;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e) { }
        private void btnAdd_Click(object sender, EventArgs e) { }
        private void btnSave_Click(object sender, EventArgs e) { }
        private void btnDelete_Click(object sender, EventArgs e) { }
        private void btnClear_Click(object sender, EventArgs e) { }
        private void btnSave_Click_1(object sender, EventArgs e) { }
        private void Form1_Load(object sender, EventArgs e) { }
    }
}